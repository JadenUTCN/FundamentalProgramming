package ro.tuc.tp.logic;

import ro.tuc.tp.model.Server;
import ro.tuc.tp.model.Task;

import java.util.List;

public class ShortestQueueStrategy implements Strategy {

    @Override
    public void addTask (List<Server> servers, Task t){
        int low = 999;
        int temp = low;
        Server tserv = servers.get(0);
        for (Server serv  : servers){
            temp = serv.getTaskSize();
            System.out.println("The waiting period for server " + serv.getId());
            System.out.println("is " + temp);

            if (temp < low){
                low = temp;
                tserv = serv;
            }
        }
        if (tserv != null) {
            tserv.addTask(t);
        }
    }




}
