package ro.tuc.tp.logic;

import ro.tuc.tp.gui.SimulationFrame;
import ro.tuc.tp.model.Task;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SimulationManager implements Runnable {


    public int timeLimit = 100;
    public int maxProcessingTime = 10;
    public int minProcessingTime = 2;
    public int numberOfServers = 3;
    public int numberOfClients = 10;
    public SelectionPolicy selectionPolicy = SelectionPolicy.SHORTEST_TIME;
    private Scheduler scheduler;

    private SimulationFrame frame;
    private List<Task> generatedTasks;

    public SimulationManager() {
        scheduler = new Scheduler(numberOfServers, 2);
        scheduler.changeStrategy(selectionPolicy);



        frame = new SimulationFrame("Queue Simulation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // frame.pack();
        frame.setVisible(true);


        generatedTasks = new ArrayList<>();
        generateNRandomTasks(numberOfClients);
    }

    private void generateNRandomTasks(int n) {

        for (int i = 0; i < n; i++) {
            int processingTime = minProcessingTime + (int) (Math.random() * (maxProcessingTime - minProcessingTime + 1));
            int arrivalTime = (int) (Math.random() * timeLimit);
            Task task = new Task(i + 1, arrivalTime, processingTime);
            generatedTasks.add(task);
        }
        Collections.sort(generatedTasks);
    }

    @Override
    public void run() {
        int currentTime = 0;
        while (currentTime < timeLimit) {

            List<Task> toDispatch = new ArrayList<>();
            for (Task task : generatedTasks) {
                if (task.getArrivalTime() == currentTime) {
                    toDispatch.add(task);
                }
            }

            for (Task task : toDispatch) {
                scheduler.dispatchTask(task);
                generatedTasks.remove(task);
            }

            frame.update(scheduler.getServers(), generatedTasks, currentTime);

            currentTime++;

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}