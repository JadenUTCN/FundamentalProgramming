package ro.tuc.tp.logic;

import ro.tuc.tp.model.Server;
import ro.tuc.tp.model.Task;

import java.util.List;

public interface Strategy {
    public void addTask(List<Server> servers, Task t);

}


