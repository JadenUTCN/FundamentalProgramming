package ro.tuc.tp.gui;

import ro.tuc.tp.logic.SimulationManager;
import ro.tuc.tp.model.Server;
import ro.tuc.tp.model.Task;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class SimulationFrame extends JFrame implements ActionListener {
    private JTextArea serversTextArea;
    private JTextArea waitingTasksTextArea;
    private JTextArea processedTasksTextArea;
    private JLabel currentTimeLabel;

    private JButton startButton;
    private JTextField numServersTextField;
    private boolean started = false;

    private static SimulationManager simManager;

    public SimulationFrame(String title) {
        setTitle(title);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Time:"));
        currentTimeLabel = new JLabel("0");
        topPanel.add(currentTimeLabel);
        mainPanel.add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(1, 3));
        serversTextArea = new JTextArea();
        serversTextArea.setEditable(false);
        JScrollPane serversScrollPane = new JScrollPane(serversTextArea);
        centerPanel.add(serversScrollPane);

        waitingTasksTextArea = new JTextArea();
        waitingTasksTextArea.setEditable(false);
        JScrollPane waitingTasksScrollPane = new JScrollPane(waitingTasksTextArea);
        centerPanel.add(waitingTasksScrollPane);

        processedTasksTextArea = new JTextArea();
        processedTasksTextArea.setEditable(false);
        JScrollPane processedTasksScrollPane = new JScrollPane(processedTasksTextArea);
        centerPanel.add(processedTasksScrollPane);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.add(new JLabel("Number of Servers:"));
        numServersTextField = new JTextField("1", 5);
        bottomPanel.add(numServersTextField);
        startButton = new JButton("Start");
        startButton.setActionCommand("Start");
        startButton.addActionListener(this);
        bottomPanel.add(startButton);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        getContentPane().add(mainPanel);
        setVisible(true);
    }

    public void update(List<Server> servers, List<Task> generatedTasks, int currentTime) {
        currentTimeLabel.setText(Integer.toString(currentTime));

        StringBuilder serversStringBuilder = new StringBuilder();
        serversStringBuilder.append(String.format("%-20s %-20s %-20s\n", "ID", "State", "Task"));
        for (Server server : servers) {
            serversStringBuilder.append(String.format("%-20d %-20s %-20s\n",
                    server.getId(),
                    server.isAvailable() ? "Available" : "Busy",
                    server.getCurrentTask() != null ? server.getCurrentTask().toString() : "-"));
        }
        serversTextArea.setText(serversStringBuilder.toString());

        // Update waiting tasks
        StringBuilder waitingTasksStringBuilder = new StringBuilder();
        waitingTasksStringBuilder.append(String.format("%-20s %-20s %-20s\n", "ID", "Arrival Time", "Processing Time"));
        for (Task task : generatedTasks) {
            waitingTasksStringBuilder.append(String.format("%-20d %-20d %-20d\n",
                    task.getId(),
                    task.getArrivalTime(),
                    task.getServiceTime()));
        }
        waitingTasksTextArea.setText(waitingTasksStringBuilder.toString());

        // Update processed tasks
        StringBuilder processedTasksStringBuilder = new StringBuilder();
        processedTasksStringBuilder.append(String.format("%-20s %-20s %-20s %-20s\n", "ID", "Arrival Time", "Processing Time", "Finish Time"));
        for (Server server : servers) {
            Task task = server.getCurrentTask();
            if (task != null && task.isProcessed()) {
                processedTasksStringBuilder.append(String.format("%-20d %-20d %-20d \n",
                        task.getId(),
                        task.getArrivalTime(),
                        task.getServiceTime()));
//                        task.getFinishTime()));
            }
        }
        processedTasksTextArea.setText(processedTasksStringBuilder.toString());
    }

    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if((command == "Start") && started == false){
            Thread t = new Thread(simManager);
            t.start();
            started = true;
        }
    }

    public static void main(String[] args) {

        simManager = new SimulationManager();

    }
}