package ro.tuc.tp.model;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class Server implements Runnable, Comparable<Server> {
    private BlockingQueue<Task> tasks;
    private AtomicInteger waitingPeriod;

    private Task currentTask;
    private int id;

    public Server(int id) {
        this.id = id;
        this.tasks = new PriorityBlockingQueue<>();
        this.waitingPeriod = new AtomicInteger(0);
    }

    public void addTask(Task newTask) {
        tasks.add(newTask);
        this.waitingPeriod.addAndGet(newTask.getServiceTime());
    }

    public void run() {
        try {
            while (true) {
                currentTask = tasks.take();

                currentTask.process();
                System.out.println("Server " + this.id);
                System.out.println("processed task: " + currentTask.getId());
                System.out.println("Sleeping for : " + currentTask.getServiceTime());
                Thread.sleep(currentTask.getServiceTime());
                this.waitingPeriod.getAndDecrement();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public int compareTo(Server other) {
        if (this.waitingPeriod.floatValue() < other.waitingPeriod.floatValue()) {
            return -1;
        } else if (this.waitingPeriod.floatValue() == other.waitingPeriod.floatValue()) {
            return 0;
        } else {
            return 1;
        }
    }

    public Task[] getTasks() {
        return tasks.toArray(new Task[tasks.size()]);
    }

    public int getTaskSize() {
        return tasks.size();
    }

    public int getWaitingPeriod() {
        return waitingPeriod.intValue();
    }

    public int getId(){
        return this.id;
    }

    public boolean isAvailable(){
        return true;
    }

    public Task getCurrentTask() {
        return currentTask;
    }
}
