package ro.tuc.tp.model;

public class Task implements Comparable{
    private int id;
    private int arrivalTime;
    private int serviceTime;

    private boolean serviced = false;

    public Task(int id, int arrivalTime, int serviceTime){
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.serviceTime = serviceTime;
    }

    public int getArrivalTime() {
        return arrivalTime;
    }
    public int getServiceTime(){
        return serviceTime;
    }
    public int getId(){
        return this.id;
    }

    public boolean isProcessed(){
        return serviced;
    }
    public void process(){
        serviced = true;
    }

    @Override
    public int compareTo(Object o) {
        if (o.hashCode() > this.hashCode()){
            return -1;
        }else if(o.hashCode() == this.hashCode()){
            return 0;
        }else{
            return 1;
        }
    }
    public String toString(){
        return String.valueOf(this.id);
    }
}
