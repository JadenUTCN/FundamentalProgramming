package ro.tuc.tp.logic;

import ro.tuc.tp.model.Server;
import ro.tuc.tp.model.Task;

import java.util.ArrayList;
import java.util.List;

public class Scheduler {

private ArrayList<Server> servers;
private int maxNoServers;
private int maxTasksPerServerr;
private Strategy strategy;



public Scheduler(int maxNoServers,int maxTasksPerServer){
    servers = new ArrayList<Server>();

    Server serv = new Server(1);
    Thread tserv = new Thread(serv);
    servers.add(serv);

    Server serv2 = new Server(2);
    Thread tserv2 = new Thread(serv2);

    servers.add(serv2);
    tserv.start();
    tserv2.start();

}
public void changeStrategy(SelectionPolicy policy){
    if (policy == SelectionPolicy.SHORTEST_QUEUE){
        //strategy = new ConcreteStrategyQueue();
        strategy = new ShortestQueueStrategy();
    }
    if (policy == SelectionPolicy.SHORTEST_TIME){
        strategy = new TimeStrategy();
    }
}

public void dispatchTask(Task t){
    strategy.addTask(this.servers,t);
}
public List<Server> getServers(){
    return servers;
}


}
