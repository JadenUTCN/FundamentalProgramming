package ro.tuc.tp.logic;

public enum SelectionPolicy {
    SHORTEST_QUEUE, SHORTEST_TIME
}
