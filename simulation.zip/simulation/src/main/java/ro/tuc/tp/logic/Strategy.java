package ro.tuc.tp.logic;

public interface Strategy {
    public void addTask(List<Server> servers, Task t);

}


