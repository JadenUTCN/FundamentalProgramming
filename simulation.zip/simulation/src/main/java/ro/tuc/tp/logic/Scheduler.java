package ro.tuc.tp.logic;

import ro.tuc.tp.model.Server;

import java.util.List;

public class Scheduler {

private List<Server> servers;
private int maxNoServers;
private int maxTasksPerServerr;
private Strategy strategy;

public enum SelectionPolicy {
    SHORTEST_QUEUE,SHORTEST_TIME
}

public void changeStrategy(SelectionPolicy policy){
    if (policy == SelectionPolicy.SHORTEST_QUEUE){
        strategy = new ConcreteStrategyQueue();
    }
    if (policy == SelectionPolicy.SHORTEST_TIME){
        strategy = new ConcreteStrategyTime();
    }
}

public void dispatchTask(Task t){

}
public List<Server> getServers(){
    return servers;
}

}
