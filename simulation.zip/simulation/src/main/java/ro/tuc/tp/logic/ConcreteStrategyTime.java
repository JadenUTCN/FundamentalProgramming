package ro.tuc.tp.logic;

public class ConcreteStrategyTime  implements Strategy{
    @Override
    public void addTask(List<Server> servers, Task t){


    }
}
