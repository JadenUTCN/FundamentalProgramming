package ro.tuc.tp.logic;

public class SimulationManager implements Runnable {
    //data read from UI
    public enum SelectionPolicy {
        SHORTEST_QUEUE, SHORTEST_TIME
    }

    public int timeLimit = 100; //maximum processing time read from UI
    public int maxProcessingTime = 10;
    public int minProcessingTime = 2;
    public int numberOfServers = 3;
    public int numberOfClients = 100;
    public SelectionPolicy selectionPolicy = SelectionPolicy.SHORTEST_TIME;
    //entity responsible with queue management and client distribution
    private Scheduler scheduler;
    //frame for displaying simulation
    private SimulationFrame frame;
    //pool of tasks (client shopping in the store)
    private List<Task> generatedTasks;

    public SimulationManager() {
        // initialize the scheduler
        scheduler = new Scheduler(numberOfServers, selectionPolicy);

        // create and start numberOfServers threads
        for (int i = 0; i < numberOfServers; i++) {
            Thread t = new Thread(scheduler);
            t.start();
        }

        // initialize frame to display simulation
        frame = new SimulationFrame(numberOfServers);

        // generate numberOfClients clients using generateNRandomTasks()
        //and store them to generatedTasks
        generatedTasks = new ArrayList<>();
        generateNRandomTasks(numberOfClients);
    }

    private void generateNRandomTasks(int n) {
        // generate N random tasks:
        //random processing time
        //minProcessingTime < processingTime < maxProcessing Time
        // random arrivalTime
        for (int i = 0; i < n; i++) {
            int processingTime = minProcessingTime + (int) (Math.random() * (maxProcessingTime - minProcessingTime + 1));
            int arrivalTime = (int) (Math.random() * timeLimit);
            Task task = new Task(i + 1, arrivalTime, processingTime);
            generatedTasks.add(task);
        }
        //sort list with respect to arrivalTime
        Collections.sort(generatedTasks);
    }

    @Override
    public void run() {
        int currentTime = 0;
        while (currentTime < timeLimit) {
            // iterate generatedTasks list and pick tasks that have the
            //arrivalTime equal with the currentTime
            List<Task> toDispatch = new ArrayList<>();
            for (Task task : generatedTasks) {
                if (task.getArrivalTime() == currentTime) {
                    toDispatch.add(task);
                }
            }
            // send tasks to queue by calling the dispatchTask method
            //from Scheduler and delete tasks from list
            for (Task task : toDispatch) {
                scheduler.dispatchTask(task);
                generatedTasks.remove(task);
            }

            // update UI frame
            frame.update(scheduler.getServers(), generatedTasks, currentTime);

            currentTime++;

            // wait an interval of 1 second
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SimulationManager simManager = new SimulationManager();
        Thread t = new Thread(simManager);
        t.start();
    }
}