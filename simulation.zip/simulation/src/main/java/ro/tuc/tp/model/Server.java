package ro.tuc.tp.model;

public class Server implements Runnable {
    private BlockingQueue<Task> tasks;
    private AtomicInteger waitingPeriod;

    public Server(){
        //init queue
    }
    public void addTask(Task newTask){

    }

    public void run(){
        while (true){

        }
    }

    public Task[] getTasks(){

    }

}
