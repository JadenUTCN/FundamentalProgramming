package ro.tuc.tp.model;

import ro.tuc.tp.model.Monomial;

import java.util.TreeMap;

public class Polynomial {

    public TreeMap<Integer, Monomial> monos;


    public int degree = -1;
    public int leadingCoef = -1;

    public Polynomial(){
        monos = new TreeMap<>();




    }
    public void ins(Monomial mono) {
        try {


            //monos.put(mono.degree,mono);
            Monomial temp = monos.get(mono.degree);

            if (temp != null) {
//            if (mono.sign) {

                temp.coef += mono.coef;
                if (mono.degree >= this.degree) {
                    this.degree = mono.degree;


                    if (temp.coef != 0) {
                        this.leadingCoef = temp.coef;
                    }


                }


//            } else {
//                temp.coef -= mono.coef;
//            }
            } else {
                monos.put(mono.degree, mono);
                if (mono.degree >= this.degree) {
                    this.degree = mono.degree;
                    if (mono.coef > this.leadingCoef) {
                        this.leadingCoef = mono.coef;

                    }


                }

            }
        } catch (Exception e) {


        }
    }

    public void recalculateDegree(){

    }

    public void printarray() {
        System.out.println("Printing array");
        for (Monomial mono : monos.values()) {
            System.out.println(mono);
        }
    }


/*
function n / d is
    require d ≠ 0
    q ← 0
    r ← n             // At each step n = d × q + r

    while r ≠ 0 and degree(r) ≥ degree(d) do
        t ← lead(r) / lead(d)       // Divide the leading terms
        q ← q + t
        r ← r − t × d

    return (q, r)
 */





//    public String getSign(int coef){
//        String sign = "+";
//        if (coef < 0){
//            sign = "";
//        }
//        return sign;
//    }

    public String toString(){
        String poly = "";
        int coef = 0;
        int degree = -1;

        Monomial temp;
        for (Monomial mono : monos.descendingMap().values()){
            coef = mono.coef;
            degree = mono.degree;
            if (coef > 0) {
                poly += "+";
            }
            coef = mono.coef;
            if (degree > 1) {
                poly += Integer.toString(coef) + "x^" + Integer.toString(degree);
            }else if (degree == 1){
                poly += coef + "x";
            }else if (degree == 0){
                poly += coef;
            }
        }


        return poly;
    }



}
