package ro.tuc.tp.logic;

import ro.tuc.tp.model.Monomial;
import ro.tuc.tp.model.Polynomial;

//package ro.tuc.tp.logic;
//
public class Operations {


    public Polynomial add(Polynomial poly1, Polynomial poly2){
        Polynomial poly3 = new Polynomial();
        for (Monomial mono : poly1.monos.values()){
            poly3.ins(mono);
        }
        for (Monomial mono : poly2.monos.values()){
            poly3.ins(mono);
        }
        return poly3;
    }
    public Polynomial sub(Polynomial poly1,Polynomial poly2){
        Polynomial poly3 = new Polynomial();
        try {
            for (Monomial mono : poly1.monos.values()) {
//            if (poly2.monos.get(mono.degree) != null){
                Monomial temp = new Monomial(mono.degree, mono.coef);
                poly3.ins(temp);

            }
            for (Monomial mono2 : poly2.monos.values()) {
                Monomial monotemp = poly3.monos.get(mono2.degree);
                if (monotemp != null) {
                    monotemp.coef -= mono2.coef;
                    if (monotemp.coef == 0) {
                        poly3.monos.remove(mono2.degree);
                        if (!poly3.monos.isEmpty()) {
                            poly3.degree = poly3.monos.lastKey();
                            poly3.leadingCoef = poly3.monos.get(poly3.degree).coef;
                        } else {
                            poly3.degree = -1;
                        }
                    }


                } else {
                    Monomial newmono = new Monomial(mono2.degree, -mono2.coef);
                    poly3.ins(newmono);
                }
            }


        }catch(Exception e){

        }finally {

            return poly3;
        }
    }
    public Polynomial mul(Polynomial poly1,Polynomial poly2){
        Polynomial poly3 = new Polynomial();
        try {
            for (Monomial mono : poly1.monos.values()) {
                for (Monomial mono2 : poly2.monos.values()) {
                    int coef;
//                boolean sign = true;
                    int degree;
                    coef = mono.coef * mono2.coef;
//
                    degree = mono.degree + mono2.degree;
                    Monomial mulMono = new Monomial(degree, coef); //sign
                    poly3.ins(mulMono);

                }
            }
        }catch(Exception e){

        }finally {
            return poly3;
        }
    }

    public Polynomial div(Polynomial poly1,Polynomial divisor) {
        Polynomial ptemp = new Polynomial();
        try {
            Polynomial quotient = new Polynomial();

            if (divisor.degree == 0) {
                if ((divisor.leadingCoef == 0)) {
                    throw new RuntimeException("We can't divide by 0, Duh!");
                }
            }
            if (poly1.degree < divisor.degree) {
                Monomial temp = new Monomial(0, 0);
                Polynomial poly = new Polynomial();
                poly.ins(temp);
                return poly;
            }

            int coef = poly1.leadingCoef / divisor.leadingCoef;
            int degree = poly1.degree - divisor.degree;
            Monomial mono = new Monomial(degree, coef);
            Polynomial polo = new Polynomial();
            polo.ins(mono);
            quotient.ins(mono);
//            Polynomial temp = new Polynomial();
            ptemp = mul(divisor, quotient);
            ptemp = sub(poly1, ptemp);
            ptemp = div(ptemp, divisor);

            ptemp = add(quotient, ptemp);


        }catch(Exception e) {

            }
        return ptemp;
//        return add(quotient, sub(poly1,div(mul(divisor,quotient),divisor) ));

//        return quotient.add(  (this.sub(divisor.mul(quotient)).div(divisor)) );
    }
//    public int add(int firstNumber, int secondNumber) {
//        return firstNumber + secondNumber;
//    }
//
//    public int subtract(int firstNumber, int secondNumber) {
//        return firstNumber - secondNumber;
//    }
//
//    public int multiply(int firstNumber, int secondNumber) {
//        return firstNumber * secondNumber;
//    }
}
